from datetime import datetime, timedelta
from django.http import HttpRequest, HttpResponse
from django.shortcuts import render, redirect
from django.contrib.auth.decorators import login_required, permission_required
from django.contrib.auth import login, authenticate, logout
from django.contrib.auth.models import User
from django.db.models import Count
from .forms import PostForm
from .models import Post
from .tasks import *
from collections import Counter

# Create your views here.
@login_required(login_url="/login")
def home(request):
    return render(request, 'main/home.html')

@login_required(login_url="/login")
@permission_required("core.add_post", login_url="/login", raise_exception=True)
def create_post(request):
    content = {
        "posts": Post.objects.all(),
        "form": PostForm(request.POST),
        "post_id": request.POST.get("post-id"),
        "permissions": request.user.has_perm('core.delete_post')
    }
    
    # check all permissions from the request user
    # print(request.user.get_all_permissions()) 

    if request.method == 'POST':
        if content["post_id"]:
            post = Post.objects.filter(id=content["post_id"]).first()
            
            if post and (post.author == request.user and content["permissions"] or request.user.has_perm("core.can_delete_post")):
                post.delete()

        if content["form"].is_valid():
            post = content["form"].save(commit=False)
            post.author = request.user
            post.save()
            return redirect("/post")
    else:
        content["form"] = PostForm()

    return render(request, 'main/post.html', content)

@login_required(login_url="/login")
def dashboard(request):
    posts = Post.objects.order_by('author').values('author').annotate(posts_count=Count('author'))
    users = User.objects.all()

    result = []

    for data in posts:
        result.append({'author' : str(users[data['author']-1].username) ,  'posts_count' : int(data['posts_count'])})

    getPostDates = Post.objects.order_by('created_at')

    getDate = Counter()
    for post_date in getPostDates:
        getDate[post_date.created_at.strftime("%Y-%m-%d")] += 1

    value_date, cont_date = zip(*getDate.items())

    return render(request, 'main/dashboard.html', {"data":result, "value_date": value_date, "cont_date": cont_date} )

@login_required(login_url="/login")
def apps(request):
    return render(request, 'main/apps.html')

@login_required(login_url="/login")
def projects(request):
    return render(request, 'main/projects.html')

@login_required(login_url="/login")
def test_async(request):
    test_add = add(2000, 2)
    return HttpResponse(test_add)