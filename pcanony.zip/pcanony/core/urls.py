from django.urls import path
from . import views

urlpatterns = [
    path('', views.home),
    path('post', views.create_post),
    path('dashboard', views.dashboard),
    path('apps', views.apps),
    path('projects', views.projects),
    path('test', views.test_async),
]