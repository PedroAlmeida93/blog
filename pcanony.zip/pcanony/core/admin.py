from django.contrib import admin
from django.db import models
from django_celery_results.admin import GroupResult
from .models import Post
# Register your models here.

# get list -> admin.site._registry

@admin.register(Post)
class Post(admin.ModelAdmin):
    list_display = ['author', 'title', 'description', 'created_at', 'updated_at']

admin.site.unregister(GroupResult)