from tkinter import Widget
from django import forms
from .models import Post

class PostForm(forms.ModelForm):
    class Meta:
        model = Post
        fields = ["title", "description"]

    def __init__(self, *args, **kwargs):
        super().__init__(*args, **kwargs)
        self.fields['title'].widget.attrs.update({'class': 'shadow appearance-none border rounded w-full py-2 px-3 text-gray-700 my-5 leading-tight focus:outline-none focus:shadow-outline'})
        self.fields['description'].widget.attrs.update({'class': 'shadow appearance-none border border-red-500 rounded w-full py-2 px-3 text-gray-700 mt-5 leading-tight focus:outline-none focus:shadow-outline'})
