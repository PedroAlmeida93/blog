from .base import *

DEBUG = False
ALLOWED_HOSTS = ['localhost', '127.0.0.1']

'''
# Start Project
python3 manage.py runserver

# Start Auto Update Tailwind
python3 manage.py tailwind start

# Run Worker Celery 
celery -A pcanony worker -l info


# Run flower :
celery -A pcanony flower --address=127.0.0.1 --port=5555

# Start worker with beat
celery -A pcanony worker -l info -B --scheduler django_celery_beat.schedulers:DatabaseScheduler

pip : 
celery==4.4.7
django-celery-beat==2.3.0
django-celery-monitor==1.1.2
django-celery-results==2.4.0
'''