from __future__ import absolute_import, unicode_literals
from ..celery import app as celery_app
from .base import *

# you need to set "pcanony = 'production'" as an environment variable

__all__ = ('celery_app',)

if os.getenv("STATUS") == 'production':
   from .production import *
else:
   from .development import *